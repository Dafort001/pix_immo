
  # Webseite Frontend Überarbeitung

  This is a code bundle for Webseite Frontend Überarbeitung. The original project is available at https://www.figma.com/design/mX8WGyL9q4ad7SDvD4CrT7/Webseite-Frontend-%C3%9Cberarbeitung.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  