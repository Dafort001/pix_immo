import { Link } from "wouter";
import Contact from "./contact";

// kontakt-formular is same as contact
export default Contact;
